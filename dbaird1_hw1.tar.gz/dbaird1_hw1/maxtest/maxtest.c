#include <stdio.h>
#include <limits.h>

int main()
{
    printf("int:\t\t%i\n", INT_MAX);
    printf("unsigned int:\t%u\n", UINT_MAX);
    return 0;
}
